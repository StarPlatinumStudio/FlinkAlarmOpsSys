
export class StreamPageCtrl {
}
StreamPageCtrl.templateUrl = 'components/stream.html';


