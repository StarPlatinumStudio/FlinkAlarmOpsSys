
export class ExampleAppConfigCtrl {
  constructor() { }
}
ExampleAppConfigCtrl.templateUrl = 'components/config.html';


